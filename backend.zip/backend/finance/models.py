from django.db import models

# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=50, default="")
    author = models.CharField(max_length=50, default="")
    published_date = models.DateField()
    
    def __str__(self):
        return self.title
    
    
    
class User(models.Model):
    username = models.CharField(max_length=255, default="")
    email = models.EmailField(max_length=50, default="")
    password = models.CharField(max_length=255)
    
    def __str__(self):
        return self.username