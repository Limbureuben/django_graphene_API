import graphene
from django.contrib.auth.models import User, Book
from graphene_django import DjangoObjectType

class UserType(DjangoObjectType):
    class Meta:
        model = User

class CreateUser(graphene.Mutation):
    user = graphene.Field(UserType)

    class Arguments:
        username = graphene.String(required=True)
        email = graphene.String(required=True)
        password = graphene.String(required=True)

    def mutate(self, info, username, password, email):
        user = User.objects.create_user(username=username, email=email, password=password)
        return CreateUser(user=user)

class UserMutation(graphene.ObjectType):
    create_user = CreateUser.Field()

schema = graphene.Schema(query=UserMutation)


class BookType(DjangoObjectType):
    class Meta:
        model = Book

class CreateBook(graphene.Mutation):
    book = graphene.Field(BookType)
    
    class Arguments:
        title = graphene.String(required=True)
        author = graphene.String(required=True)
        published_date = graphene.Date(required=True)
        
    def mutate(self, info, title, author, published_date):
        # Create the book object
        book = Book.objects.create(title=title, author=author, published_date=published_date)
        return CreateBook(book=book)
        
class BookMutation(graphene.ObjectType):
    create_book = CreateBook.Field()


schema = graphene.Schema(query=BookMutation)